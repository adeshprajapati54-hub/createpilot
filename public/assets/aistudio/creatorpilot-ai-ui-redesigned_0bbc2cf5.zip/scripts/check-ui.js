const fs = require('fs');
const path = require('path');
const assert = require('assert');
const root = path.resolve(__dirname, '..');
const htmlPath = path.join(root, 'public', 'index.html');
const cssPath = path.join(root, 'public', 'styles.css');
const jsPath = path.join(root, 'public', 'app.js');

for (const file of [htmlPath, cssPath, jsPath]) {
  assert(fs.existsSync(file), `Missing required file: ${path.relative(root, file)}`);
}
const html = fs.readFileSync(htmlPath, 'utf8');
const css = fs.readFileSync(cssPath, 'utf8');
const js = fs.readFileSync(jsPath, 'utf8');

const requiredIds = ['topNavbar', 'navMenu', 'mobileToggle', 'workspace', 'features', 'pricing', 'faq', 'download'];
for (const id of requiredIds) {
  assert(new RegExp(`id=["']${id}["']`).test(html), `Missing expected element id="${id}"`);
}
assert(html.includes('class="hero-product-preview"'), 'Missing responsive product preview');
assert(html.includes('aria-controls="navMenu"'), 'Mobile nav toggle should declare its controlled menu');
assert(css.includes('@media (max-width: 900px)'), 'Missing tablet/mobile responsive breakpoint');
assert(css.includes('@media (max-width: 600px)'), 'Missing small-mobile responsive breakpoint');
assert(css.includes('@media (max-width: 380px)'), 'Missing narrow-phone responsive breakpoint');
assert(css.includes('.nav-menu.mobile-open'), 'Mobile menu open state is not styled');
assert(js.includes("mobileToggle.setAttribute('aria-expanded', String(isOpen))"), 'Mobile menu should expose expanded state');
assert(js.includes("event.key === 'Escape'"), 'Mobile menu should close on Escape');
assert(js.includes("navMenu.querySelectorAll('a')"), 'Mobile menu should close after selecting a link');

const ids = [...html.matchAll(/\bid=["']([^"']+)["']/g)].map(m => m[1]);
const duplicates = ids.filter((id, index) => ids.indexOf(id) !== index);
assert(duplicates.length === 0, `Duplicate HTML ids found: ${[...new Set(duplicates)].join(', ')}`);

console.log('CreatorPilot UI checks passed.');
console.log(`Checked ${requiredIds.length} core navigation/workspace anchors, responsive breakpoints, mobile navigation accessibility hooks, and ${ids.length} unique HTML IDs.`);
